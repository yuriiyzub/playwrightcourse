    async function addToIG(ig) {
        if (navigator.joinAdInterestGroup) {
            try {
                await navigator.joinAdInterestGroup(ig, 2592000000);
            } catch(e) {
                fetch('https://ams.creativecdn.com/ig-membership' + '?ig='+ encodeURIComponent(ig.name) + '&err=' +  encodeURIComponent(e.toString().substring(0, 256))).catch(() => {});
            }
        }
    }

    addToIG({"owner":"https://f.creativecdn.com","name":"ndSEJroTcjTbjgXRTYM8","biddingLogicURL":"https://f.creativecdn.com/statics/buyer.js","biddingWasmHelperURL":"https://f.creativecdn.com/statics/buyer.wasm","trustedBiddingSignalsURL":"https://f.creativecdn.com/bidder/tbsweb/bids","trustedBiddingSignalsKeys":["v5_H2Sf7KzLpr3KKcMARnmvSFWnuL6f5lpGwlkopcCfeFQjZomskNuMuR_ztSBchY4bZ28c1RdfHZLGzIh3smvDlFVNTAUhSfkEpiy6Jhpm96c"],"ads":[],"adComponents":[],"priority":0.0,"executionMode":"compatibility","auctionServerRequestFlags":["omit-ads"],"updateURL":"https://f.creativecdn.com/update-ig?ntk=yI3ZD2n8Du14BO8-7E_wGb--GRVNFfcnlDkqw9tnoPaWL35ALNU81MtC2Tj-6F5QuBausiUAhR-7pUrjlSTqkqH5C4f531FfzZJNB-Pz1JkU8RZUeaMxXPz1RG8uf5dW","privateAggregationConfig":{"aggregationCoordinatorOrigin":"https://publickeyservice.msmt.gcp.privacysandboxservices.com"}});
