    async function addToIG(ig) {
        if (navigator.joinAdInterestGroup) {
            try {
                await navigator.joinAdInterestGroup(ig, 2592000000);
            } catch(e) {
                fetch('https://ams.creativecdn.com/ig-membership' + '?ig='+ encodeURIComponent(ig.name) + '&err=' +  encodeURIComponent(e.toString().substring(0, 256))).catch(() => {});
            }
        }
    }

    addToIG({"owner":"https://f.creativecdn.com","name":"ndSEJroTcjTbjgXRTYM8","biddingLogicURL":"https://f.creativecdn.com/statics/buyer.js","biddingWasmHelperURL":"https://f.creativecdn.com/statics/buyer.wasm","trustedBiddingSignalsURL":"https://f.creativecdn.com/bidder/tbsweb/bids","trustedBiddingSignalsKeys":["v5_9QqVMPElaILWZE90U2MoLcf9_8DArHV6wvLgKCiII30cgPcQhjmrRc3dUGaBOSbOc_6cMufmzBawXJaGt-RXdnok6wUClb1ECGmB4tBnfPc"],"ads":[],"adComponents":[],"priority":0.0,"executionMode":"compatibility","auctionServerRequestFlags":["omit-ads"],"updateURL":"https://f.creativecdn.com/update-ig?ntk=yI3ZD2n8Du14BO8-7E_wGb--GRVNFfcnlDkqw9tnoPYzBnpOvGjICOEW7c8KcKaqe3UOzTFH8KMGpx4XQf-TLdrHktiHU1zvwtLgAU0fBiwDg1D-dAdgUtdqyYgr01Li","privateAggregationConfig":{"aggregationCoordinatorOrigin":"https://publickeyservice.msmt.gcp.privacysandboxservices.com"}});
